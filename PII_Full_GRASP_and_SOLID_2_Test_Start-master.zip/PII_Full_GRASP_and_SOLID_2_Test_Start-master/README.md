# PII Full GRASP and SOLID [Test]
## FIT
### Universidad Católica del Uruguay

En este programa trabajaremos sobre el resultado obtenido luego de hacer [Full GRASP and Solid Parte 2](https://github.com/ucudal/PII_Full_GRASP_and_SOLID_2_Start).

Se provee en este repositorio el código de la parte 2 de Full GRASP & SOLID ya implementado.

## Desafío(s)

▶️ Evaluar qué casos de test son necesarios para comprobar que el código provisto funciona correctamente.

▶️ Implementar dichos casos de test. Justificar utilizando comentarios en el código la existencia de cada uno de los casos implementados (desafío anterior).

## Anexo

### ¿Cómo agregar un proyecto de Test?

Este repositorio *ya incluye* un proyecto de test, pero de ser necesario crear uno en otra instancia, lo podemos crear fácilemente utilizando [comandos de consola](https://github.com/ucudal/PII_Comandos).